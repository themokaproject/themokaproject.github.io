Moka Platform beta by Vincent Barth�l�my, Thomas Barth�l�my, Thomas Keunebroek and Alexandre Masciulli
http://themokaproject.github.io

To run the platform, just open moka.html in your browser. This beta version is optimized for Google Chrome.

Enjoy