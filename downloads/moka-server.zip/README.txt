Moka - Server beta by Alexandre Masciulli, Thomas Keunebroek, Vincent Barth�l�my, Thomas Barth�l�my
http://themokaproject.github.io

Windows users :
to launch server, just run moka-server.cmd

Mac OS and Linux users :
to launch server, open a terminal and run 'java -jar moka-server.jar'

WARNING :
you can only run one instance at a time

Enjoy